// accessing the head text of  the page
document.getElementById('head').style.color='red';
// accessing the second paragraph and adding text to the paragraph
document.getElementById("headline").innerHTML = "What is JavaScript?";
document.getElementById("headline").style.fontFamily ="sans-sarif";
document.getElementById("headline").style.fontSize ="35px";
// accessing the descriptin paragraph and adding text to the paragraph
document.getElementById("discription").innerHTML = "JavaScript is a wildly popular interpreted scripting language that in early 2019 became the language most frequently learned by developers. JavaScript is an open standard, not controlled by any single vendor, with numerous implementations and an easy-to-learn syntax that makes it popular with beginners and veteran developers alike.";
document.getElementById("discription").style.fontFamily ="Arial";
document.getElementById("discription").style.fontSize ="20px";
document.getElementById('discription').style.color='blue';